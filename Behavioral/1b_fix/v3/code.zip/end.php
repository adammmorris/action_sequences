<div id="end_div" class="center-content">
  <p><b>Thank you for your participation!</b></p> In order to complete this HIT, you must enter the code below into Turk.
  
  <p style = 'color: red; font-size: 40px'>
      <br><br>Your secret completion code is:<br><br><br><?php echo $_GET['turkcode'] ?><br><br><br>Copy this code now. <br><br>
  </p>
  
  <p>(Once you've copied it, you can exit this window.)</p>
</div>