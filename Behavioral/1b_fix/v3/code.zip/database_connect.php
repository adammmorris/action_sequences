<?php

$dbc = mysql_connect('127.0.0.1', 'moral', 'j|n321');
mysql_select_db('adam', $dbc);

?>